"""
MERGE with PRIMARY KEY (Single Key = user_id) - WINDOWS VERSION
One row per user in the table
Updates either UPDATE existing user OR INSERT new user
"""

import os
import sys
import logging
from pathlib import Path
from pyspark.sql import SparkSession

# ============================================================
# UTF-8 CONSOLE SUPPORT
# ============================================================
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# ============================================================
# SETUP PATHS - UPDATE THESE FOR YOUR SYSTEM
# ============================================================
# Change these paths to match where you saved the parquet files
INPUT_FILES_PATH = r"C:\Users\ue\Documents\Task\Files\Spark-Iceberg Data Pipeline\primary_key"
WAREHOUSE_PATH = r"C:\Users\ue\Documents\Task\Files\Spark-Iceberg Data Pipeline\warehouse_primary"

# ============================================================
# SETUP LOGGING
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================
# VERIFY FILES EXIST
# ============================================================
primary_master_path = os.path.join(INPUT_FILES_PATH, "primary_master.parquet")
primary_updates_path = os.path.join(INPUT_FILES_PATH, "primary_updates.parquet")

logger.info(f"Looking for files at: {INPUT_FILES_PATH}")
logger.info(f"primary_master.parquet exists: {os.path.exists(primary_master_path)}")
logger.info(f"primary_updates.parquet exists: {os.path.exists(primary_updates_path)}")

if not os.path.exists(primary_master_path):
    logger.error(f"File not found: {primary_master_path}")
    logger.error("Please make sure the parquet files are in the primary_key folder!")
    sys.exit(1)

if not os.path.exists(primary_updates_path):
    logger.error(f"File not found: {primary_updates_path}")
    logger.error("Please make sure the parquet files are in the primary_key folder!")
    sys.exit(1)

logger.info("All files found! Proceeding...")

# ============================================================
# START SPARK WITH ICEBERG
# ============================================================
logger.info("Starting Spark with Iceberg for PRIMARY KEY MERGE...")
spark = (
    SparkSession.builder
    .appName("MERGE-Primary-Key")
    .master("local[4]")
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1")
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.local.type", "hadoop")
    .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH)
    .config("spark.sql.shuffle.partitions", "4")
    .getOrCreate()
)

try:
    # Create namespace
    spark.sql("CREATE NAMESPACE IF NOT EXISTS local.db")
    logger.info("Namespace ready: local.db")

    # ============================================================
    # STEP 1: READ MASTER DATA (ONE ROW PER USER)
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 1: READ MASTER DATA (PRIMARY KEY = user_id)")
    logger.info("=" * 70)

    logger.info(f"Reading from: {primary_master_path}")
    df_master = spark.read.parquet(primary_master_path)
    logger.info(f"Master data loaded - {df_master.count()} rows")
    logger.info("Table structure: ONE row per USER (user_id is PRIMARY KEY)")
    df_master.show()

    # ============================================================
    # STEP 2: WRITE TO ICEBERG TABLE
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 2: WRITE MASTER DATA TO ICEBERG TABLE")
    logger.info("=" * 70)

    df_master.writeTo("local.db.users_primary") \
        .using("iceberg") \
        .tableProperty("format-version", "2") \
        .createOrReplace()

    logger.info("Initial data written to Iceberg table")
    spark.sql("SELECT * FROM local.db.users_primary").show()

    # ============================================================
    # STEP 3: READ UPDATE DATA
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 3: READ UPDATE DATA (PRIMARY KEY MERGE)")
    logger.info("=" * 70)

    logger.info(f"Reading from: {primary_updates_path}")
    df_updates = spark.read.parquet(primary_updates_path)
    logger.info(f"Update data loaded - {df_updates.count()} records")
    logger.info("Expected behavior:")
    logger.info("  - U001 (exists) -> MATCHED -> UPDATE")
    logger.info("  - U003 (exists) -> MATCHED -> UPDATE")
    logger.info("  - U006 (new) -> NOT MATCHED -> INSERT")
    df_updates.show()

    df_updates.createOrReplaceTempView("updates_primary")

    # ============================================================
    # STEP 4: MERGE INTO WITH PRIMARY KEY
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 4: MERGE INTO (PRIMARY KEY: user_id)")
    logger.info("=" * 70)
    logger.info("SQL: ON t.user_id = u.user_id")
    logger.info("This matches records by USER ONLY (one row per user)")

    spark.sql("""
        MERGE INTO local.db.users_primary AS t
        USING updates_primary AS u
        ON t.user_id = u.user_id
        WHEN MATCHED THEN
            UPDATE SET
                t.user_name = u.user_name,
                t.user_age = u.user_age,
                t.user_income = u.user_income,
                t.status = u.status
        WHEN NOT MATCHED THEN
            INSERT (user_id, user_name, user_age, user_income, status)
            VALUES (u.user_id, u.user_name, u.user_age, u.user_income, u.status)
    """)

    logger.info("MERGE completed successfully!")
    logger.info("Result: 5 initial + 1 new = 6 rows expected")

    # ============================================================
    # STEP 5: VERIFY RESULTS
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 5: VERIFY MERGE RESULTS")
    logger.info("=" * 70)

    result = spark.sql("SELECT * FROM local.db.users_primary ORDER BY user_id")
    result.show()

    logger.info(f"Total rows: {result.count()}")

    # Check matched records
    matched = spark.sql("""
        SELECT user_id, user_name, user_age, user_income
        FROM local.db.users_primary
        WHERE user_id IN ('U001', 'U003')
    """)
    logger.info("MATCHED records (Updated):")
    matched.show()

    # Check not matched records
    not_matched = spark.sql("""
        SELECT user_id, user_name, user_age, user_income
        FROM local.db.users_primary
        WHERE user_id = 'U006'
    """)
    logger.info("NOT MATCHED records (Inserted):")
    not_matched.show()

    # ============================================================
    # STEP 6: SHOW SNAPSHOTS
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 6: ICEBERG SNAPSHOT HISTORY")
    logger.info("=" * 70)

    spark.sql("""
        SELECT snapshot_id, committed_at, operation
        FROM local.db.users_primary.snapshots
        ORDER BY committed_at DESC
    """).show(truncate=False)

    logger.info("=" * 70)
    logger.info("PRIMARY KEY MERGE COMPLETED SUCCESSFULLY!")
    logger.info("=" * 70)
    logger.info(f"Warehouse location: {WAREHOUSE_PATH}")

    print("\n" + "=" * 70)
    print("SPARK UI AVAILABLE AT: http://localhost:4040")
    print("=" * 70)
    print("\nPress ENTER when done viewing Spark UI...")
    input()

except Exception as e:
    logger.error(f"Error: {str(e)}", exc_info=True)
    raise

finally:
    if spark is not None:
        spark.stop()
        logger.info("Spark stopped")