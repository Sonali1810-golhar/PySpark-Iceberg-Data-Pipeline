"""
Simple Spark + Iceberg Pipeline - ALL IN ONE FILE
Read → Transform → Write → Merge → Export
KEEPS SPARK UI ALIVE UNTIL USER PRESSES ENTER
"""

import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv
from pyspark.sql import SparkSession
from pyspark.sql.functions import when

# ============================================================
# UTF-8 CONSOLE SUPPORT
# ============================================================
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# ============================================================
# STEP 1: LOAD ENVIRONMENT & PATHS
# ============================================================
load_dotenv()

WAREHOUSE_PATH = os.getenv("WAREHOUSE_PATH", "./warehouse")
LOG_PATH = os.getenv("LOG_PATH", "./log_path")
INPUT_FILES_PATH = os.getenv("INPUT_FILES_PATH", "./input_files")
OUTPUT_FILES_PATH = os.getenv("OUTPUT_FILES_PATH", "./output_files")
SPARK_MASTER = os.getenv("SPARK_MASTER", "local[4]")

# Create directories if they do not exist
for path in [WAREHOUSE_PATH, LOG_PATH, INPUT_FILES_PATH, OUTPUT_FILES_PATH]:
    Path(path).mkdir(parents=True, exist_ok=True)

# ============================================================
# STEP 2: SETUP LOGGING
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(f"{LOG_PATH}/app.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================
# STEP 3: PRINT CONFIGURATION
# ============================================================
logger.info("=" * 60)
logger.info("CONFIGURATION")
logger.info("=" * 60)
logger.info(f"Warehouse: {WAREHOUSE_PATH}")
logger.info(f"Input Files: {INPUT_FILES_PATH}")
logger.info(f"Output Files: {OUTPUT_FILES_PATH}")
logger.info(f"Spark Master: {SPARK_MASTER}")
logger.info("=" * 60)

# ============================================================
# STEP 4: START SPARK WITH ICEBERG
# ============================================================
logger.info("Starting Spark with Iceberg...")
spark = (
    SparkSession.builder
    .appName("Simple-Spark-Iceberg")
    .master(SPARK_MASTER)
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1")
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.local.type", "hadoop")
    .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH)
    .config("spark.sql.shuffle.partitions", "4")
    .getOrCreate()
)

logger.info("Spark started successfully")

# Create Iceberg namespace
spark.sql("CREATE NAMESPACE IF NOT EXISTS local.db")
logger.info("Namespace ready: local.db")

try:
    # ============================================================
    # STEP 5: READ MASTER DATA
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 1: READ MASTER DATA")
    logger.info("=" * 60)

    master_file = f"{INPUT_FILES_PATH}/master_data.parquet"
    df_master = spark.read.parquet(master_file)
    logger.info(f"Master data loaded from: {master_file}")
    logger.info(f"Rows: {df_master.count()}")
    df_master.show()

    # ============================================================
    # STEP 6: READ EVENTS DATA
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 2: READ EVENTS DATA")
    logger.info("=" * 60)

    events_file = f"{INPUT_FILES_PATH}/events_data.parquet"
    df_events = spark.read.parquet(events_file)
    logger.info(f"Events data loaded from: {events_file}")
    logger.info(f"Rows: {df_events.count()}")
    df_events.show()

    # ============================================================
    # STEP 7: TRANSFORM (JOIN + SEGMENTATION)
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 3: TRANSFORM")
    logger.info("=" * 60)
    logger.info("Rule: is_valid_target = (user_age >= 25) AND (user_income >= 50000)")

    # Join master and events data
    df_joined = df_events.join(df_master, "user_id", "left")

    # Add target segmentation
    df_transformed = df_joined.withColumn(
        "is_valid_target",
        when(
            (df_joined.user_age >= 25) & (df_joined.user_income >= 50000),
            True
        ).otherwise(False)
    )

    logger.info("Transformation complete")
    df_transformed.show()

    # Count valid and invalid targets
    valid_count = df_transformed.filter("is_valid_target = true").count()
    invalid_count = df_transformed.filter("is_valid_target = false").count()
    logger.info(f"Valid targets: {valid_count}")
    logger.info(f"Invalid targets: {invalid_count}")

    # ============================================================
    # STEP 8: WRITE TO ICEBERG TABLE
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 4: WRITE TO ICEBERG TABLE")
    logger.info("=" * 60)
    logger.info("Table: local.db.listings")

    df_transformed.writeTo("local.db.listings") \
        .using("iceberg") \
        .tableProperty("format-version", "2") \
        .createOrReplace()

    logger.info("Data written successfully to Iceberg")
    spark.sql("SELECT * FROM local.db.listings").show()

    # ============================================================
    # STEP 9: READ UPDATE DATA
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 5: READ UPDATE DATA")
    logger.info("=" * 60)

    updates_file = f"{INPUT_FILES_PATH}/events_updates.parquet"
    df_updates = spark.read.parquet(updates_file)
    logger.info(f"Update records loaded from: {updates_file}")
    logger.info(f"Rows: {df_updates.count()}")
    df_updates.show()

    # Register temporary view
    df_updates.createOrReplaceTempView("updates")

    # ============================================================
    # STEP 10: MERGE INTO ICEBERG
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 6: MERGE INTO")
    logger.info("=" * 60)
    logger.info("Executing MERGE INTO...")

    spark.sql("""
        MERGE INTO local.db.listings AS t
        USING updates AS u
        ON t.user_id = u.user_id
        WHEN MATCHED THEN
            UPDATE SET
                t.campaign_id = u.campaign_id,
                t.impressions = u.impressions,
                t.clicks = u.clicks,
                t.spend = u.spend
        WHEN NOT MATCHED THEN
            INSERT (user_id, campaign_id, impressions, clicks, spend)
            VALUES (u.user_id, u.campaign_id, u.impressions, u.clicks, u.spend)
    """)

    logger.info("MERGE completed successfully")
    spark.sql("SELECT * FROM local.db.listings").show()

    # ============================================================
    # STEP 11: SHOW ICEBERG SNAPSHOT HISTORY
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 7: ICEBERG TABLE HISTORY")
    logger.info("=" * 60)

    spark.sql("""
        SELECT committed_at, snapshot_id, operation
        FROM local.db.listings.snapshots
    """).show(truncate=False)

    # ============================================================
    # STEP 12: EXPORT FINAL DATA TO CSV
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 8: EXPORT TO CSV")
    logger.info("=" * 60)

    csv_output_path = OUTPUT_FILES_PATH
    logger.info(f"Exporting final data to: {csv_output_path}")

    spark.sql("SELECT * FROM local.db.listings") \
        .coalesce(1) \
        .write \
        .option("header", "true") \
        .mode("overwrite") \
        .csv(csv_output_path)

    logger.info("CSV exported successfully")
    spark.sql("SELECT * FROM local.db.listings").show()

    # ============================================================
    # STEP 13: ANALYZE EXECUTION
    # ============================================================
    logger.info("=" * 60)
    logger.info("STEP 9: ANALYZE EXECUTION")
    logger.info("=" * 60)
    logger.info("Grouping data by is_valid_target")

    spark.sql("""
        SELECT is_valid_target, COUNT(*) AS record_count, AVG(spend) AS avg_spend
        FROM local.db.listings
        GROUP BY is_valid_target
    """).show()

    # ============================================================
    # FINAL MESSAGE - KEEP SPARK UI ALIVE
    # ============================================================
    logger.info("=" * 60)
    logger.info("PIPELINE COMPLETED SUCCESSFULLY")
    logger.info("=" * 60)
    logger.info(f"CSV Output Directory: {csv_output_path}")
    logger.info("Spark UI available at: http://localhost:4040")
    logger.info("Spark application is running for Spark UI access...")

    print("\n" + "=" * 60)
    print("PIPELINE COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print("\nSpark UI: http://localhost:4040")
    print("Open in your browser to view execution details")
    print("\nPress ENTER when finished viewing Spark UI...")
    print("=" * 60 + "\n")

    # ============================================================
    # KEEP SPARK ALIVE UNTIL USER PRESSES ENTER
    # ============================================================
    input("Press ENTER to stop Spark and exit: ")

except Exception as e:
    logger.error(f"Pipeline failed: {str(e)}", exc_info=True)
    raise

finally:
    # Stop Spark only after ENTER is pressed
    if spark is not None:
        spark.stop()
        logger.info("Spark stopped")