from pyspark.sql import SparkSession
import os
from dotenv import load_dotenv

load_dotenv()
WAREHOUSE_PATH = os.getenv("WAREHOUSE_PATH", "./warehouse")

spark = SparkSession.builder \
    .appName("View-Snapshots") \
    .master("local[4]") \
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.local.type", "hadoop") \
    .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH) \
    .getOrCreate()

print("\n" + "="*80)
print("ALL YOUR SNAPSHOTS")
print("="*80)

# View 1: Simple snapshot list
print("\n1. SIMPLE SNAPSHOT LIST (All versions):")
print("-" * 80)
spark.sql("""
    SELECT
        ROW_NUMBER() OVER (ORDER BY committed_at) as version_number,
        committed_at as timestamp,
        snapshot_id,
        operation,
        CAST(summary['total-records'] AS INT) as total_rows
    FROM local.db.listings.snapshots
    ORDER BY committed_at
""").show(100, truncate=False)

# View 2: Detailed snapshot info
print("\n2. DETAILED SNAPSHOT INFO:")
print("-" * 80)
spark.sql("""
    SELECT
        ROW_NUMBER() OVER (ORDER BY committed_at) as version,
        committed_at as created_at,
        snapshot_id,
        operation,
        CAST(summary['added-records'] AS INT) as added,
        CAST(summary['deleted-records'] AS INT) as deleted,
        CAST(summary['total-records'] AS INT) as total
    FROM local.db.listings.snapshots
    ORDER BY committed_at
""").show(100, truncate=False)

# View 3: Table history (which snapshot is current)
print("\n3. TABLE HISTORY (Current & Past Versions):")
print("-" * 80)
spark.sql("""
    SELECT
        made_current_at as timestamp,
        snapshot_id,
        CASE WHEN is_current_ancestor THEN 'CURRENT' ELSE 'PAST' END as status,
        parent_id
    FROM local.db.listings.history
    ORDER BY made_current_at DESC
""").show(100, truncate=False)

# View 4: Count snapshots
print("\n4. SNAPSHOT STATISTICS:")
print("-" * 80)
total_snapshots = spark.sql("""
    SELECT COUNT(*) as total FROM local.db.listings.snapshots
""").collect()[0][0]

append_ops = spark.sql("""
    SELECT COUNT(*) as count FROM local.db.listings.snapshots 
    WHERE operation = 'append'
""").collect()[0][0]

overwrite_ops = spark.sql("""
    SELECT COUNT(*) as count FROM local.db.listings.snapshots 
    WHERE operation = 'overwrite'
""").collect()[0][0]

print(f"Total snapshots: {total_snapshots}")
print(f"Append operations: {append_ops}")
print(f"Overwrite operations: {overwrite_ops}")

# View 5: Time-travel example
print("\n5. TIME-TRAVEL EXAMPLE (View old snapshot):")
print("-" * 80)

first_snapshot = spark.sql("""
    SELECT snapshot_id FROM local.db.listings.snapshots 
    ORDER BY committed_at LIMIT 1
""").collect()[0][0]

print(f"\nFirst snapshot ID: {first_snapshot}")
print("Data from first snapshot (10 rows):\n")
spark.sql(f"""
    SELECT * FROM local.db.listings VERSION AS OF {first_snapshot}
""").show()

print("\nCurrent data:\n")
spark.sql("SELECT COUNT(*) as total_rows FROM local.db.listings").show()

spark.stop()