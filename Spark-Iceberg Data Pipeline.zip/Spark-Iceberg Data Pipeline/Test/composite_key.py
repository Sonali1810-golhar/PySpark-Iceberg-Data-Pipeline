"""
MERGE with COMPOSITE KEY (user_id + campaign_id) - WINDOWS VERSION
Multiple rows per user (one per campaign)
Updates match on BOTH user_id AND campaign_id
"""

import os
import sys
import logging
from pathlib import Path
from pyspark.sql import SparkSession

# ============================================================
# UTF-8 CONSOLE SUPPORT
# ============================================================
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# ============================================================
# SETUP PATHS - UPDATE THESE FOR YOUR SYSTEM
# ============================================================
# Change these paths to match where you saved the parquet files
INPUT_FILES_PATH = r"C:\Users\ue\Documents\Task\Files\Spark-Iceberg Data Pipeline\composite_key"
WAREHOUSE_PATH = r"C:\Users\ue\Documents\Task\Files\Spark-Iceberg Data Pipeline\warehouse_composite"

# ============================================================
# SETUP LOGGING
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================
# VERIFY FILES EXIST
# ============================================================
composite_master_path = os.path.join(INPUT_FILES_PATH, "composite_master.parquet")
composite_updates_path = os.path.join(INPUT_FILES_PATH, "composite_updates.parquet")

logger.info(f"Looking for files at: {INPUT_FILES_PATH}")
logger.info(f"composite_master.parquet exists: {os.path.exists(composite_master_path)}")
logger.info(f"composite_updates.parquet exists: {os.path.exists(composite_updates_path)}")

if not os.path.exists(composite_master_path):
    logger.error(f"File not found: {composite_master_path}")
    logger.error("Please make sure the parquet files are in the composite_key folder!")
    sys.exit(1)

if not os.path.exists(composite_updates_path):
    logger.error(f"File not found: {composite_updates_path}")
    logger.error("Please make sure the parquet files are in the composite_key folder!")
    sys.exit(1)

logger.info("All files found! Proceeding...")

# ============================================================
# START SPARK WITH ICEBERG
# ============================================================
logger.info("Starting Spark with Iceberg for COMPOSITE KEY MERGE...")
spark = (
    SparkSession.builder
    .appName("MERGE-Composite-Key")
    .master("local[4]")
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1")
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
    .config("spark.sql.catalog.local.type", "hadoop")
    .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH)
    .config("spark.sql.shuffle.partitions", "4")
    .getOrCreate()
)

try:
    # Create namespace
    spark.sql("CREATE NAMESPACE IF NOT EXISTS local.db")
    logger.info("Namespace ready: local.db")

    # ============================================================
    # STEP 1: READ MASTER DATA (MULTIPLE ROWS PER USER)
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 1: READ MASTER DATA (COMPOSITE KEY = user_id + campaign_id)")
    logger.info("=" * 70)

    logger.info(f"Reading from: {composite_master_path}")
    df_master = spark.read.parquet(composite_master_path)
    logger.info(f"Master data loaded - {df_master.count()} rows")
    logger.info("Table structure: MULTIPLE rows per USER (one per CAMPAIGN)")
    logger.info("Each unique (user_id, campaign_id) pair = ONE record")
    df_master.show()

    # ============================================================
    # STEP 2: WRITE TO ICEBERG TABLE
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 2: WRITE MASTER DATA TO ICEBERG TABLE")
    logger.info("=" * 70)

    df_master.writeTo("local.db.campaigns_composite") \
        .using("iceberg") \
        .tableProperty("format-version", "2") \
        .createOrReplace()

    logger.info("Initial data written to Iceberg table")
    spark.sql("SELECT * FROM local.db.campaigns_composite ORDER BY user_id, campaign_id").show()

    # ============================================================
    # STEP 3: READ UPDATE DATA
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 3: READ UPDATE DATA (COMPOSITE KEY MERGE)")
    logger.info("=" * 70)

    logger.info(f"Reading from: {composite_updates_path}")
    df_updates = spark.read.parquet(composite_updates_path)
    logger.info(f"Update data loaded - {df_updates.count()} records")
    logger.info("Expected behavior (matching on BOTH user_id AND campaign_id):")
    logger.info("  - U001 + C001 (exists) -> MATCHED -> UPDATE")
    logger.info("  - U001 + C004 (new) -> NOT MATCHED -> INSERT")
    logger.info("  - U002 + C001 (exists) -> MATCHED -> UPDATE")
    logger.info("  - U004 + C001 (new) -> NOT MATCHED -> INSERT")
    df_updates.show()

    df_updates.createOrReplaceTempView("updates_composite")

    # ============================================================
    # STEP 4: MERGE INTO WITH COMPOSITE KEY
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 4: MERGE INTO (COMPOSITE KEY: user_id + campaign_id)")
    logger.info("=" * 70)
    logger.info("SQL: ON t.user_id = u.user_id AND t.campaign_id = u.campaign_id")
    logger.info("This matches records by BOTH user_id AND campaign_id")
    logger.info("Same user in different campaigns = different records!")

    spark.sql("""
        MERGE INTO local.db.campaigns_composite AS t
        USING updates_composite AS u
        ON t.user_id = u.user_id AND t.campaign_id = u.campaign_id
        WHEN MATCHED THEN
            UPDATE SET
                t.campaign_name = u.campaign_name,
                t.impressions = u.impressions,
                t.clicks = u.clicks,
                t.spend = u.spend,
                t.status = u.status
        WHEN NOT MATCHED THEN
            INSERT (user_id, campaign_id, campaign_name, impressions, clicks, spend, status)
            VALUES (u.user_id, u.campaign_id, u.campaign_name, u.impressions, u.clicks, u.spend, u.status)
    """)

    logger.info("MERGE completed successfully!")
    logger.info("Result: 5 initial + 2 new = 7 rows expected")

    # ============================================================
    # STEP 5: VERIFY RESULTS
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 5: VERIFY MERGE RESULTS")
    logger.info("=" * 70)

    result = spark.sql("SELECT * FROM local.db.campaigns_composite ORDER BY user_id, campaign_id")
    result.show()

    logger.info(f"Total rows: {result.count()}")

    # ============================================================
    # STEP 6: ANALYZE BY USER
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 6: RECORDS BY USER (showing multiple campaigns per user)")
    logger.info("=" * 70)

    analysis = spark.sql("""
        SELECT user_id, COUNT(*) as campaigns_count, SUM(spend) as total_spend
        FROM local.db.campaigns_composite
        GROUP BY user_id
        ORDER BY user_id
    """)
    logger.info("Summary - Campaigns per User:")
    analysis.show()

    # ============================================================
    # STEP 7: SHOW MATCHED vs NOT MATCHED
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 7: MATCHED RECORDS (Updated)")
    logger.info("=" * 70)

    matched = spark.sql("""
        SELECT user_id, campaign_id, campaign_name, impressions, clicks, spend
        FROM local.db.campaigns_composite
        WHERE (user_id = 'U001' AND campaign_id = 'C001')
           OR (user_id = 'U002' AND campaign_id = 'C001')
        ORDER BY user_id, campaign_id
    """)
    matched.show()

    logger.info("=" * 70)
    logger.info("STEP 8: NOT MATCHED RECORDS (Inserted)")
    logger.info("=" * 70)

    not_matched = spark.sql("""
        SELECT user_id, campaign_id, campaign_name, impressions, clicks, spend
        FROM local.db.campaigns_composite
        WHERE (user_id = 'U001' AND campaign_id = 'C004')
           OR (user_id = 'U004' AND campaign_id = 'C001')
        ORDER BY user_id, campaign_id
    """)
    not_matched.show()

    # ============================================================
    # STEP 9: SHOW SNAPSHOTS
    # ============================================================
    logger.info("=" * 70)
    logger.info("STEP 9: ICEBERG SNAPSHOT HISTORY")
    logger.info("=" * 70)

    spark.sql("""
        SELECT snapshot_id, committed_at, operation
        FROM local.db.campaigns_composite.snapshots
        ORDER BY committed_at DESC
    """).show(truncate=False)

    logger.info("=" * 70)
    logger.info("COMPOSITE KEY MERGE COMPLETED SUCCESSFULLY!")
    logger.info("=" * 70)
    logger.info(f"Warehouse location: {WAREHOUSE_PATH}")

    print("\n" + "=" * 70)
    print("SPARK UI AVAILABLE AT: http://localhost:4040")
    print("=" * 70)
    print("\nPress ENTER when done viewing Spark UI...")
    input()

except Exception as e:
    logger.error(f"Error: {str(e)}", exc_info=True)
    raise

finally:
    if spark is not None:
        spark.stop()
        logger.info("Spark stopped")