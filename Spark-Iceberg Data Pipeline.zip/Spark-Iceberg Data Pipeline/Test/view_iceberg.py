from pyspark.sql import SparkSession
import os
from dotenv import load_dotenv

load_dotenv()
WAREHOUSE_PATH = os.getenv("WAREHOUSE_PATH", "./warehouse")

spark = SparkSession.builder \
    .appName("View-Iceberg") \
    .master("local[4]") \
    .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.local.type", "hadoop") \
    .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH) \
    .getOrCreate()

# VIEW ALL DATA
print("\n=== ALL DATA IN TABLE ===\n")
spark.sql("SELECT * FROM local.db.listings").show()

# VIEW SCHEMA
print("\n=== TABLE SCHEMA ===\n")
spark.sql("DESC TABLE local.db.listings").show()

# COUNT ROWS
print("\n=== ROW COUNT ===\n")
spark.sql("SELECT COUNT(*) as total_rows FROM local.db.listings").show()

# VIEW BY SEGMENT
print("\n=== VALID TARGETS ===\n")
spark.sql("SELECT * FROM local.db.listings WHERE is_valid_target = true").show()

print("\n=== INVALID TARGETS ===\n")
spark.sql("SELECT * FROM local.db.listings WHERE is_valid_target = false").show()

spark.stop()