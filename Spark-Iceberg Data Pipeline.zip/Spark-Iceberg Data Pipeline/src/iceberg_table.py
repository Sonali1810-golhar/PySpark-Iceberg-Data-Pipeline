"""
Step 5: Inspect Iceberg table (snapshots, history)
"""
import logging
from config import TABLE_NAME

logger = logging.getLogger(__name__)

def show_snapshots(spark):
    """Show table snapshots and metadata"""
    try:
        table_full_name = f"local.db.{TABLE_NAME}"

        logger.info("=" * 60)
        logger.info("INSPECT: Table Snapshots & History")
        logger.info("=" * 60)

        # Show snapshots
        logger.info("\n1. SNAPSHOTS (all versions):")
        snapshots = spark.sql(f"SELECT * FROM {table_full_name}.snapshots")
        snapshots.show(truncate=False)

        # Show files
        logger.info("\n2. FILES (current snapshot):")
        files = spark.sql(f"SELECT * FROM {table_full_name}.files")
        files.show(truncate=False)

        # Show history
        logger.info("\n3. HISTORY:")
        try:
            history = spark.sql(f"SELECT * FROM {table_full_name}.history")
            history.show(truncate=False)
        except:
            logger.info("(History table not available)")

        logger.info("\n✓ Inspection complete!")

    except Exception as e:
        logger.error(f"✗ Inspection error: {str(e)}")
        raise