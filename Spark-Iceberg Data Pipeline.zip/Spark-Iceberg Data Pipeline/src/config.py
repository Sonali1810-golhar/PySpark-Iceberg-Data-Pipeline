"""
Setup Spark and load paths from .env file
"""
import os
import sys
import logging
from dotenv import load_dotenv
from pyspark.sql import SparkSession

# Ensure console can render UTF-8 log symbols (Windows default codepage can't)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# Load .env file
load_dotenv()

# Get paths from .env
WAREHOUSE_PATH = os.getenv("WAREHOUSE_PATH")
LOG_PATH = os.getenv("LOG_PATH")
INPUT_FILES_PATH = os.getenv("INPUT_FILES_PATH")
OUTPUT_FILES_PATH = os.getenv("OUTPUT_FILES_PATH", os.getenv("INPUT_FILES_PATH"))
SPARK_MASTER = os.getenv("SPARK_MASTER", "local[4]")

# Table name
TABLE_NAME = "listings"

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f"{LOG_PATH}/application.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def get_spark():
    """Start Spark with Iceberg"""
    try:
        spark = SparkSession.builder \
            .appName("Spark-Iceberg Real Estate Pipeline") \
            .master(SPARK_MASTER) \
            .config("spark.jars.packages", "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.1") \
            .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
            .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog") \
            .config("spark.sql.catalog.local.type", "hadoop") \
            .config("spark.sql.catalog.local.warehouse", WAREHOUSE_PATH) \
            .config("spark.sql.shuffle.partitions", "4") \
            .getOrCreate()

        logger.info("✓ Spark started successfully")
        return spark
    except Exception as e:
        logger.error(f"✗ Spark startup error: {str(e)}")
        raise

def print_paths():
    """Show all configured paths"""
    logger.info("=" * 60)
    logger.info("CONFIGURATION")
    logger.info("=" * 60)
    logger.info(f"Warehouse: {WAREHOUSE_PATH}")
    logger.info(f"Input files: {INPUT_FILES_PATH}")
    logger.info(f"Output files: {OUTPUT_FILES_PATH}")
    logger.info(f"Logs: {LOG_PATH}")
    logger.info(f"Spark: {SPARK_MASTER}")
    logger.info("=" * 60 + "\n")

def ensure_namespace(spark):
    """Create namespace if not exists"""
    try:
        spark.sql("CREATE NAMESPACE IF NOT EXISTS local.db")
        logger.info("✓ Namespace ready: local.db")
    except Exception as e:
        logger.warning(f"Namespace warning: {str(e)}")