"""
Step 6: Export final data to CSV
"""
import logging
from config import OUTPUT_FILES_PATH, TABLE_NAME

logger = logging.getLogger(__name__)

def export_to_csv(spark):
    """Export Iceberg table to CSV"""
    try:
        table_full_name = f"local.db.{TABLE_NAME}"

        logger.info("=" * 60)
        logger.info("EXPORT: Save to CSV")
        logger.info("=" * 60)

        # Read table
        logger.info(f"Reading table: {table_full_name}")
        df = spark.table(table_full_name)
        row_count = df.count()
        logger.info(f"✓ Rows to export: {row_count}")

        # Export to CSV
        csv_path = f"{OUTPUT_FILES_PATH}/final_data.csv"
        logger.info(f"\nExporting to: {csv_path}")

        df.coalesce(1).write \
            .option("header", "true") \
            .mode("overwrite") \
            .csv(csv_path)

        logger.info("✓ Exported to CSV!")
        logger.info(f"File: {csv_path}")

        # Show preview
        logger.info("\nCSV Preview:")
        df.show(truncate=False)

    except Exception as e:
        logger.error(f"✗ Export error: {str(e)}")
        raise