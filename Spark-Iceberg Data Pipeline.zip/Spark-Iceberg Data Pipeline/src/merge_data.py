"""
Step 4: MERGE INTO - Update + Insert new rows
"""
import logging
from config import TABLE_NAME

logger = logging.getLogger(__name__)

def merge_updates(spark, df_updates):
    """
    MERGE updates into Iceberg table
    - Update existing rows (match by user_id)
    - Insert new rows
    """
    try:
        table_full_name = f"local.db.{TABLE_NAME}"

        logger.info("=" * 60)
        logger.info("MERGE INTO: Update + Insert")
        logger.info("=" * 60)

        # Get current table count
        before_count = spark.table(table_full_name).count()
        logger.info(f"Before MERGE: {before_count} rows")

        # Register updates as temp table
        logger.info("\nRegistering update data...")
        df_updates.createOrReplaceTempView("updates_temp")
        logger.info(f"✓ Update records: {df_updates.count()}")
        df_updates.show()

        # MERGE INTO SQL
        logger.info("\nExecuting MERGE INTO...")
        merge_sql = f"""
        MERGE INTO {table_full_name} t
        USING updates_temp u
        ON t.user_id = u.user_id
        WHEN MATCHED THEN
            UPDATE SET
                campaign_id = u.campaign_id,
                impressions = u.impressions,
                clicks = u.clicks,
                spend = u.spend
        WHEN NOT MATCHED THEN
            INSERT (user_id, campaign_id, impressions, clicks, spend)
            VALUES (u.user_id, u.campaign_id, u.impressions, u.clicks, u.spend)
        """

        spark.sql(merge_sql)
        logger.info("✓ MERGE executed!")

        # Get after count
        after_count = spark.table(table_full_name).count()
        logger.info(f"\nAfter MERGE: {after_count} rows")
        logger.info(f"Change: +{after_count - before_count} rows")

        # Show result
        logger.info("\nTable after MERGE:")
        result = spark.table(table_full_name)
        result.show(truncate=False)

    except Exception as e:
        logger.error(f"✗ MERGE error: {str(e)}")
        raise