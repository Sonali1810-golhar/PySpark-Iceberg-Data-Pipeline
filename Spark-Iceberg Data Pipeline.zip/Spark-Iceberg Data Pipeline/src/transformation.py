"""
Step 2: Transform data (join + add segmentation)
"""
import logging
from pyspark.sql.functions import col, when

logger = logging.getLogger(__name__)

def transform_data(spark, df_events, df_master):
    """
    Join events with master data
    Add is_valid_target = (age >= 25) AND (income >= 50000)
    """
    try:
        logger.info("=" * 60)
        logger.info("TRANSFORMATION: Join + Segmentation")
        logger.info("=" * 60)

        # JOIN events with master on user_id
        logger.info("Step 1: Joining events with master data...")
        df_joined = df_events.join(df_master, on='user_id', how='left')
        logger.info(f"✓ Joined! Rows: {df_joined.count()}")

        # Add segmentation column
        logger.info("\nStep 2: Adding is_valid_target column...")
        logger.info("Rule: age >= 25 AND income >= 50000")

        df_transformed = df_joined.withColumn(
            'is_valid_target',
            when((col('user_age') >= 25) & (col('user_income') >= 50000), True).otherwise(False)
        )

        logger.info("✓ Transformation complete!\n")
        logger.info("Result:")
        df_transformed.show(truncate=False)

        # Show summary
        valid_count = df_transformed.filter(col('is_valid_target') == True).count()
        invalid_count = df_transformed.filter(col('is_valid_target') == False).count()
        logger.info(f"\nSummary:")
        logger.info(f"  Valid targets (age >= 25 AND income >= 50000): {valid_count}")
        logger.info(f"  Invalid targets: {invalid_count}")

        return df_transformed

    except Exception as e:
        logger.error(f"✗ Transformation error: {str(e)}")
        raise