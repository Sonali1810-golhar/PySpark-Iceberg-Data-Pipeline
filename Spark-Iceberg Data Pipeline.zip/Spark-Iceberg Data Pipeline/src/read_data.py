"""
Step 1: Read parquet files (master data + events)
"""
import logging
from config import INPUT_FILES_PATH

logger = logging.getLogger(__name__)

def read_master_data(spark):
    """Read master data (user age, income)"""
    try:
        parquet_path = f"{INPUT_FILES_PATH}/master_data.parquet"
        df_master = spark.read.parquet(parquet_path)

        logger.info(f"✓ Read master data: {parquet_path}")
        logger.info(f"✓ Rows: {df_master.count()}")
        df_master.show()

        return df_master
    except Exception as e:
        logger.error(f"✗ Error reading master data: {str(e)}")
        raise

def read_events_data(spark):
    """Read events data (impressions, clicks, spend)"""
    try:
        parquet_path = f"{INPUT_FILES_PATH}/events_data.parquet"
        df_events = spark.read.parquet(parquet_path)

        logger.info(f"✓ Read events data: {parquet_path}")
        logger.info(f"✓ Rows: {df_events.count()}")
        df_events.show()

        return df_events
    except Exception as e:
        logger.error(f"✗ Error reading events data: {str(e)}")
        raise

def read_update_events(spark):
    """Read update events (for MERGE INTO)"""
    try:
        parquet_path = f"{INPUT_FILES_PATH}/events_updates.parquet"
        df_updates = spark.read.parquet(parquet_path)

        logger.info(f"✓ Read update events: {parquet_path}")
        logger.info(f"✓ Rows: {df_updates.count()}")
        df_updates.show()

        return df_updates
    except Exception as e:
        logger.error(f"✗ Error reading update events: {str(e)}")
        raise