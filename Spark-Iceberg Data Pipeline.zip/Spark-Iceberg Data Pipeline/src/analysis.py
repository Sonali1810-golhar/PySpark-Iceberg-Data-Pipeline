"""
Step 7: Analyze Spark execution (jobs, stages, tasks)
"""
import logging
from pyspark.sql.functions import count, avg, col
from config import TABLE_NAME

logger = logging.getLogger(__name__)

def analyze_execution(spark):
    """Run queries and show Spark execution details"""
    try:
        table_full_name = f"local.db.{TABLE_NAME}"

        logger.info("=" * 60)
        logger.info("ANALYSIS: Spark Execution")
        logger.info("=" * 60)

        # Query 1: Aggregation
        logger.info("\n1. QUERY: Group by is_valid_target")
        logger.info("(This query requires a SHUFFLE)")

        df = spark.table(table_full_name)
        query1 = df.groupBy("is_valid_target").agg(
            count("*").alias("count"),
            avg("spend").alias("avg_spend")
        )

        logger.info("\nExecution Plan:")
        query1.explain(mode="formatted")

        logger.info("\nResults:")
        query1.show()

        # Query 2: Join
        logger.info("\n2. QUERY: Self-join on campaign_id")
        logger.info("(This also requires a SHUFFLE)")

        listings = spark.table(table_full_name)
        query2 = listings.alias("a").join(
            listings.alias("b"),
            (col("a.campaign_id") == col("b.campaign_id")) &
            (col("a.user_id") < col("b.user_id")),
            "inner"
        )

        logger.info("\nExecution Plan:")
        query2.explain(mode="formatted")

        join_count = query2.count()
        logger.info(f"\nJoin results: {join_count} pairs")

        logger.info("\n" + "=" * 60)
        logger.info("Open Spark UI: http://localhost:4040")
        logger.info("=" * 60)

    except Exception as e:
        logger.error(f"✗ Analysis error: {str(e)}")
        raise