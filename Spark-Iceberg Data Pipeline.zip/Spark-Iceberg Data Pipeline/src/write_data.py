"""
Step 3: Write data to Iceberg table
"""
import logging
from config import TABLE_NAME

logger = logging.getLogger(__name__)

def write_to_iceberg(spark, df):
    """Write transformed data to Iceberg table"""
    try:
        table_full_name = f"local.db.{TABLE_NAME}"

        logger.info("=" * 60)
        logger.info("WRITE: Saving to Iceberg table")
        logger.info("=" * 60)

        logger.info(f"Writing to: {table_full_name}")
        logger.info(f"Rows: {df.count()}")

        # Write to Iceberg
        df.writeTo(table_full_name) \
            .using("iceberg") \
            .tableProperty("format-version", "2") \
            .createOrReplace()

        logger.info("✓ Written to Iceberg table!")

        # Verify
        result = spark.table(table_full_name)
        logger.info(f"✓ Verified: {result.count()} rows in table\n")
        result.show(truncate=False)

    except Exception as e:
        logger.error(f"✗ Write error: {str(e)}")
        raise