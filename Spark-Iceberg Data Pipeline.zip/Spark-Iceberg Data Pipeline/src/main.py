"""
Main entry point - Run Real Estate Ad Targeting Pipeline

Just run: python main.py
Or run specific steps: python main.py load | merge | history | export | jobs
"""
import sys
import logging
from config import get_spark, print_paths, ensure_namespace

import read_data
import transformation
import write_data
import merge_data
import iceberg_table
import export_csv
import analysis

logger = logging.getLogger(__name__)

def main():
    """Main pipeline"""

    # If no command given, run EVERYTHING (all)
    if len(sys.argv) < 2:
        command = "all"
    else:
        command = sys.argv[1]

    # Print config
    print_paths()

    # Start Spark
    spark = get_spark()
    ensure_namespace(spark)

    try:
        if command == "load":
            logger.info("\n" + "=" * 60)
            logger.info("STEP 1-3: Load, Transform, Write")
            logger.info("=" * 60)

            df_master = read_data.read_master_data(spark)
            df_events = read_data.read_events_data(spark)
            df_transformed = transformation.transform_data(spark, df_events, df_master)
            write_data.write_to_iceberg(spark, df_transformed)

            logger.info("\n✓ LOAD complete!")

        elif command == "merge":
            logger.info("\n" + "=" * 60)
            logger.info("STEP 4: MERGE INTO")
            logger.info("=" * 60)

            df_updates = read_data.read_update_events(spark)
            merge_data.merge_updates(spark, df_updates)

            logger.info("\n✓ MERGE complete!")

        elif command == "history":
            logger.info("\n" + "=" * 60)
            logger.info("STEP 5: Inspect History")
            logger.info("=" * 60)

            iceberg_table.show_snapshots(spark)

            logger.info("\n✓ HISTORY inspection complete!")

        elif command == "export":
            logger.info("\n" + "=" * 60)
            logger.info("STEP 6: Export to CSV")
            logger.info("=" * 60)

            export_csv.export_to_csv(spark)

            logger.info("\n✓ EXPORT complete!")

        elif command == "jobs":
            logger.info("\n" + "=" * 60)
            logger.info("STEP 7: Analyze Execution")
            logger.info("=" * 60)

            analysis.analyze_execution(spark)

            logger.info("\n✓ ANALYSIS complete!")

        elif command == "all":
            logger.info("\n" + "=" * 80)
            logger.info("🚀 RUNNING FULL PIPELINE (START TO END)...")
            logger.info("=" * 80 + "\n")

            # Step 1-3: Load, Transform, Write
            logger.info("STEP 1: Read Master Data")
            df_master = read_data.read_master_data(spark)

            logger.info("\nSTEP 2: Read Events Data")
            df_events = read_data.read_events_data(spark)

            logger.info("\nSTEP 3: Transform (Join + Segmentation)")
            df_transformed = transformation.transform_data(spark, df_events, df_master)

            logger.info("\nSTEP 4: Write to Iceberg Table")
            write_data.write_to_iceberg(spark, df_transformed)

            # Step 5: Merge
            logger.info("\nSTEP 5: MERGE INTO with Updates")
            df_updates = read_data.read_update_events(spark)
            merge_data.merge_updates(spark, df_updates)

            # Step 6: History
            logger.info("\nSTEP 6: Inspect Table History")
            iceberg_table.show_snapshots(spark)

            # Step 7: Export
            logger.info("\nSTEP 7: Export to CSV")
            export_csv.export_to_csv(spark)

            # Step 8: Analyze
            logger.info("\nSTEP 8: Analyze Spark Execution")
            analysis.analyze_execution(spark)

            logger.info("\n" + "=" * 80)
            logger.info("✓✓✓ FULL PIPELINE COMPLETE! ✓✓✓")
            logger.info("=" * 80 + "\n")

        else:
            logger.error(f"Unknown command: {command}")
            print("\nUsage:")
            print("  python main.py          (runs FULL pipeline)")
            print("  python main.py load     (load + transform + write)")
            print("  python main.py merge    (merge with updates)")
            print("  python main.py history  (view table history)")
            print("  python main.py export   (export to CSV)")
            print("  python main.py jobs     (analyze execution)")
            print("  python main.py all      (same as no argument)")

    except Exception as e:
        logger.error(f"✗ Pipeline error: {str(e)}", exc_info=True)
        raise

    finally:
        spark.stop()
        logger.info("✓ Spark stopped\n")

if __name__ == "__main__":
    main()